# Meskot — Android app (Capacitor wrapper)

`www/index.html` is your Meskot app, copied unchanged. Nothing is rewritten.

## Easiest: build the APK on GitHub (no Android Studio)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo → **Actions** → **Build Meskot APK** → **Run workflow**.
3. When it finishes (~5–8 min) open the run → **Artifacts** → download **Meskot-APK** → unzip → `app-debug.apk`.
4. Send the APK to your phone and install it (allow "install unknown apps").

## Or on your computer
```
npm install
npx cap add android
python3 scripts/patch_android.py
npx capacitor-assets generate --android
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## Updating the app later
Replace `www/index.html` with the new file, push to GitHub, run the workflow again.

## Firebase
Firebase console → Authentication → Settings → Authorized domains: make sure `localhost` is listed
(the app runs inside the APK at https://localhost).
Google/Facebook popup sign-in may not work inside the APK; email + password does.
