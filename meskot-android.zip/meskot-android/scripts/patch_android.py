"""Adds the permissions Meskot needs to AndroidManifest.xml. Does not touch the web app."""
import re, sys
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
perms = ['INTERNET','ACCESS_NETWORK_STATE','CAMERA','RECORD_AUDIO','MODIFY_AUDIO_SETTINGS',
         'ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','POST_NOTIFICATIONS',
         'READ_MEDIA_IMAGES','READ_MEDIA_VIDEO']
add = ''
for x in perms:
    line = '<uses-permission android:name="android.permission.%s" />' % x
    if line not in s and ('android.permission.%s"' % x) not in s:
        add += '    ' + line + '\n'
for f in ('camera', 'microphone'):
    line = '<uses-feature android:name="android.hardware.%s" android:required="false" />' % f
    if line not in s: add += '    ' + line + '\n'
s = s.replace('</manifest>', add + '</manifest>', 1)
open(p, 'w', encoding='utf-8').write(s)
print('manifest patched')
